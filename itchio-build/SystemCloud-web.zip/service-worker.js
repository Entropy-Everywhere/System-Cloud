const CACHE_NAME = 'system-cloud-cache-v2';
const APP_SHELL = [
  './',
  './index.html',
  './style.css',
  './manifest.json',
  './icons/SystemCloudLogo.png',
  './pages/login.html',
  './pages/signup.html',
  './pages/homepage.html',
  './pages/alters.html',
  './pages/fronters.html',
  './pages/Account/AccountView.html',
  './pages/alter-profile.html',
  './pages/firebase-config.js',
  './pages/database.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return response;
      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match('./index.html')))
  );
});
